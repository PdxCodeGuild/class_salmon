from django.contrib import admin

from .models import Pokemon, Type

admin.site.register(Pokemon)
admin.site.register(Type)
